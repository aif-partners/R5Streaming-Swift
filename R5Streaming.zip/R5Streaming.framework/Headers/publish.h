//
//  publish.h
//  
//
//  Created by Andy Zupko on 9/25/14.
//  Copyright (c) 2014 Infrared5. All rights reserved.
//

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif
typedef struct client_ctx client_ctx;

#ifdef __cplusplus
}
#endif
