//
//  R5BandwidthURLConnection.h
//  red5streaming
//
//  Created by Kyle Kellogg on 8/15/17.
//  Copyright © 2017 Infrared5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface R5BandwidthURLConnection : NSURLConnection

@property (nonatomic, strong) NSMutableDictionary *dictionary;

@end
